import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const projectRoot = dirname(fileURLToPath(import.meta.url));

// Durante esta primera etapa conservamos el juego actual en www/index.html.
// Vite permite servirlo localmente y hacer una compilación web de producción.
export default defineConfig({
  root: resolve(projectRoot, 'www'),
  publicDir: false,
  server: { host: '0.0.0.0', port: 5173, strictPort: true },
  build: {
    outDir: resolve(projectRoot, 'dist'),
    emptyOutDir: true,
    rollupOptions: { input: resolve(projectRoot, 'www/index.html') }
  }
});
